export const passwordRegex= /^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]*$/;
