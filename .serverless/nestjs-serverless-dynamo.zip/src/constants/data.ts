export const MIN_PASSWORD_LENGTH = 6;
export const MAX_PASSWORD_LENGTH = 50;
export const MIN_NAME_LENGTH = 2;
export const MAX_NAME_LENGTH = 30;
